(function () {
	console.log("Hello world!");
	var myapp = angular.module("myapp", ["firebase", 'luegg.directives' /* Scroll Glue */]);
	var FIREBASE_URL = "https://intense-fire-61.firebaseio.com/";
	var MY_TWITTER_ID = "912739170";
	var userFirebase = null;


	/* Directives */
	myapp.directive("scrollBottom", function(){
		return {
			link: function(scope, element, attr){
				var $id= $("#" + attr.scrollBottom);
				$(element).on("click", function(){
                	$id.scrollTop($id[0].scrollHeight);
            	});
        	}
    	}
	});

	myapp.factory('PresenceService', ['$rootScope', function ($rootScope) {
		var onlineUsers = 0;
		var presenceRef = new Firebase(FIREBASE_URL + 'presence/');

		presenceRef.on('value', function (snapshot) {
			onlineUsers = snapshot.numChildren();
			$rootScope.$broadcast('onOnlineUser');
		});

		var getOnlineUserCount = function () {
			return onlineUsers;
		};

		return {
			getOnlineUserCount: getOnlineUserCount
		};
	}]);

	/* Controllers */
	myapp.controller('ChatCtrl', ['$scope', '$firebase', '$firebaseSimpleLogin', function ($scope, $firebase, $firebaseSimpleLogin) {
		/* Login logic */
		var authRef = new Firebase(FIREBASE_URL);
		var auth = new FirebaseSimpleLogin(authRef, function (error, user) {
			if (error) {
				console.log(error);
			} else if (user) {
				console.log('User ID: ' + user.id + ', Provider: ' + user.provider);
				$scope.user = user;
				var messagesRef = new Firebase(FIREBASE_URL + 'messages/' + $scope.user.id);
				$scope.messages = $firebase(messagesRef);
			} else {
				/* Log every visitor in anonymously */
				auth.login('anonymous', {
					rememberMe: true
				});
			}
		});
		$scope.submitMessage = function () {
			$scope.messages.$add({
				content: $scope.content,
				by: $scope.user.id
			});
			$scope.content = "";
		};

		$scope.isDerickOnline = false;

		$scope.$on('onOnlineUser', function () {
			$scope.$apply(function () {
				if (PresenceService.getOnlineUserCount() >= 1) {
					$scope.isDerickOnline = true;
				} else {
					$scope.isDerickOnline = false;
				}
			});
		});
		
	}]);
})();